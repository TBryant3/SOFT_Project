var chatServer = require("../chat-server");
var assert = require("chai").assert;

suite("Chat test suite", function () {
    test("Test Chat pop-up", function () {
        var status = yes || no;
    } 
})