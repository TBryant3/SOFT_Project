$(function ()
{
        //connects to socket
        var socket = io();
        //ref to the div message form
        var $messageForm = $('#messageForm');
        //ref to input box with id message
        var $messageInput = $('#messageInput');
        //ref to div chat
        var $chat = $('#chat');

        var test = $messageInput.val('');
        var $people = $('#people');

        $messageForm.submit(function (e)
        {
            e.preventDefault();
        socket.emit("Send a message", $('#messageInput').val());
        $('#messageInput').val('');
        return false;
    });

    // New Message Event
    socket.on("new message", function (msg)
        {
            $chat.append($('<li>').text(msg) + '<div id="circle"> ' + "User 1" + ' </div>' + '<br>');
    });
    //Detectng a new user in the chat
    socket.on("new user", function (msg)
        {
            $people.append('<br>' + '<div id="circle1"> ' + ' </div>' + '<br>');
    });
    //Detecting user leaving chat
    socket.on("user left", function (msg)
        {
            $("#circle1").remove();
    });
});
//Log of user messages
showlog = false;
window.setInterval(function ()
    {
        if (showlog == false)
        {
            var chat = document.getElementById("chat");
        chat.scrollTop = chat.scrollHeight;

        var people = document.getElementById("people");
        people.scrollTop = people.scrollHeight;
    }
}, 4);

function showl()
    {
            showlog = true;
    }

    function hidel()
    {
        var chat = document.getElementById("chat");
        chat.scrollTop = chat.scrollHeight;
        showlog = false;

        var people = document.getElementById("people");
        people.scrollTop = people.scrollHeight;
        showlog = false;
    }

</script>


